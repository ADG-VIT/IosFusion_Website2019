//
//  ViewController.swift
//  Magic 8 Ball
//
//  Created by Sarvad shetty on 11/12/17.
//  Copyright © 2017 Sarvad shetty. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    var arrayNam:[String]=["ball1","ball2","ball3","ball4","ball5"]
    var indexNumber :Int = 0
    
    
    @IBOutlet weak var imageView: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func actionButton(_ sender: UIButton) {
        buttonPressed()
        
       
    }
    func buttonPressed(){
        indexNumber = Int(arc4random_uniform(5))
         imageView.image = UIImage(named: arrayNam[indexNumber])
        
    }

    @IBAction func backAction(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    override func motionEnded(_ motion: UIEventSubtype, with event: UIEvent?) {
        buttonPressed()
    }
}

