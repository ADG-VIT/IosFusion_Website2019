//
//  ViewController.swift
//  flashChat
//
//  Created by Sarvad shetty on 9/15/19.
//  Copyright © 2019 Sarvad shetty. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    //set variables
    //set images
    
    //set profile name
    
    //set last message
    
    
    //set tableview iboutlet
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //set delegate
        
        //set datasource

        
    }


    //tableview functions
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return number of cells
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //set cell
        let cell = chatTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ChatTableViewCell
        
        //set image
        
        //circular image
        
        //set name
        
        //set last message
        
        return cell
    }
}

