//
//  ChatTableViewCell.swift
//  flashChat
//
//  Created by Sarvad shetty on 9/15/19.
//  Copyright © 2019 Sarvad shetty. All rights reserved.
//

import UIKit

class ChatTableViewCell: UITableViewCell {


    //outlet for imageview
    
    //outlet for name label
    
    //outlet for last message
    
    
}
